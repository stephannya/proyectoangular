export interface Cliente{
    nombre:String;
    direccion:String;
    telefono:String;
    cedula:String;
}